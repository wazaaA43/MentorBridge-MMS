# Project docs go here

## Dashboard & Reporting (merged)
- `backend/src/services/reporting.js` – SQL-backed admin report calculations
- `backend/src/routes/reports.js` – `/api/reports/{dashboard,summary,capacity,expertise}` (admin/coach token required, optional `from`/`to` YYYY-MM-DD)
- `backend/test/reporting.test.js` – report tests
- `frontend/dashboard.js` – loaded after `app.js`; renders the admin Overview and Mentors tabs from the reports API
