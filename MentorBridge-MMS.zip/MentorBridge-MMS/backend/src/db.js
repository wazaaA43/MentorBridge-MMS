const fs = require('fs');
const path = require('path');
const Database = require('better-sqlite3');

const dbPath = process.env.DB_PATH || path.join(__dirname, '..', 'data', 'mentoring.db');
if (dbPath !== ':memory:') fs.mkdirSync(path.dirname(dbPath), { recursive: true });

const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(fs.readFileSync(path.join(__dirname, 'schema.sql'), 'utf8'));

// Migration: databases created before pricing existed need the hourly_rate column.
const mentorCols = db.prepare('PRAGMA table_info(mentors)').all().map((c) => c.name);
if (!mentorCols.includes('hourly_rate')) {
  db.exec('ALTER TABLE mentors ADD COLUMN hourly_rate INTEGER NOT NULL DEFAULT 0');
}

module.exports = db;
