const router = require('express').Router();
const db = require('../db');
const { requireAuth, requireRole } = require('../middleware/auth');
const { buildAdminReport, adminSummary } = require('../services/reporting');

function report(req) {
  return buildAdminReport(db, { from: req.query.from, to: req.query.to });
}

router.get('/dashboard', requireAuth, requireRole('admin', 'coach'), (req, res) => {
  res.json(report(req));
});

router.get('/summary', requireAuth, requireRole('admin', 'coach'), (req, res) => {
  res.json(adminSummary(report(req)));
});

router.get('/capacity', requireAuth, requireRole('admin', 'coach'), (req, res) => {
  res.json(report(req).mentors);
});

router.get('/expertise', requireAuth, requireRole('admin', 'coach'), (req, res) => {
  res.json(report(req).requested_expertise);
});

module.exports = router;
