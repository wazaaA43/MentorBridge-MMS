const SESSION_STATUSES = ['requested', 'confirmed', 'completed', 'cancelled', 'no_show'];
const ACTION_STATUSES = ['open', 'in_progress', 'complete', 'overdue'];
const DATE_RE = /^\d{4}-\d{2}-\d{2}$/;
const { DISPLAY_STATUS } = require('./actions');

const hrs = (minutes) => Math.round(((minutes || 0) / 60) * 10) / 10;
const pct = (part, whole) => (whole ? Math.round((part / whole) * 1000) / 10 : null);

function tally(rows, keys) {
  const out = Object.fromEntries(keys.map((key) => [key, 0]));
  for (const row of rows) out[row.k] = row.c;
  return out;
}

function validateDateRange(from, to) {
  if ((from && !DATE_RE.test(from)) || (to && !DATE_RE.test(to))) {
    throw Object.assign(new Error('from and to must be YYYY-MM-DD'), { status: 400 });
  }
}

function buildAdminReport(db, { from, to, now = new Date().toISOString() } = {}) {
  validateDateRange(from, to);
  const lo = from ? `${from}T00:00:00.000Z` : '0000-01-01';
  const hi = to ? `${to}T23:59:59.999Z` : '9999-12-31';
  const range = 's.start_at >= ? AND s.start_at <= ?';
  const rangeParams = [lo, hi];

  const mentorStatus = tally(
    db.prepare('SELECT status AS k, COUNT(*) AS c FROM mentors GROUP BY status').all(),
    ['active', 'paused', 'inactive']
  );
  const menteeStatus = tally(
    db.prepare('SELECT status AS k, COUNT(*) AS c FROM mentees GROUP BY status').all(),
    ['active', 'completed', 'withdrawn']
  );
  const matchedActiveMentees = db
    .prepare(
      `SELECT COUNT(DISTINCT me.id) AS count
         FROM mentees me JOIN matches m ON m.mentee_id = me.id
        WHERE me.status = 'active' AND m.status = 'active'`
    )
    .get().count;
  const activeMatches = db.prepare("SELECT COUNT(*) AS count FROM matches WHERE status = 'active'").get().count;

  const sessionsByStatus = tally(
    db.prepare(`SELECT s.status AS k, COUNT(*) AS c FROM sessions s WHERE ${range} GROUP BY s.status`).all(...rangeParams),
    SESSION_STATUSES
  );
  const totalMinutes = db
    .prepare(`SELECT COALESCE(SUM(s.duration_min),0) AS minutes FROM sessions s WHERE s.status = 'completed' AND ${range}`)
    .get(...rangeParams).minutes;
  const hoursByMonth = db
    .prepare(
      `SELECT substr(s.start_at,1,7) AS month, SUM(s.duration_min) AS minutes, COUNT(*) AS sessions
         FROM sessions s WHERE s.status = 'completed' AND ${range}
        GROUP BY month ORDER BY month`
    )
    .all(...rangeParams)
    .map((row) => ({ month: row.month, hours: hrs(row.minutes), sessions: row.sessions }));

  const mentors = db
    .prepare(
      `SELECT mo.id AS mentor_id, u.name, mo.capacity, mo.status, mo.hourly_rate,
              (SELECT COUNT(*) FROM matches x WHERE x.mentor_id = mo.id AND x.status = 'active') AS active_mentees,
              COALESCE(SUM(CASE WHEN s.status = 'completed' THEN s.duration_min END),0) AS minutes,
              COALESCE(SUM(s.status = 'completed'),0) AS completed_sessions,
              COALESCE(SUM(s.status = 'no_show'),0) AS no_shows
         FROM mentors mo JOIN users u ON u.id = mo.user_id
         LEFT JOIN matches m ON m.mentor_id = mo.id
         LEFT JOIN sessions s ON s.match_id = m.id AND ${range}
        GROUP BY mo.id ORDER BY minutes DESC, u.name`
    )
    .all(...rangeParams)
    .map((row) => ({
      mentor_id: row.mentor_id,
      name: row.name,
      status: row.status,
      capacity: row.capacity,
      hourly_rate: row.hourly_rate,
      active_mentees: row.active_mentees,
      remaining: Math.max(row.capacity - row.active_mentees, 0),
      full: row.active_mentees >= row.capacity,
      hours: hrs(row.minutes),
      completed_sessions: row.completed_sessions,
      no_shows: row.no_shows,
    }));

  const requestedExpertise = db
    .prepare(
      `SELECT c.name AS category,
              (SELECT COUNT(*) FROM mentee_needs n JOIN mentees me ON me.id = n.mentee_id
                WHERE n.category_id = c.id AND me.status = 'active') AS requested,
              (SELECT COUNT(*) FROM mentee_needs n JOIN mentees me ON me.id = n.mentee_id
                WHERE n.category_id = c.id AND me.status = 'active'
                  AND NOT EXISTS (SELECT 1 FROM matches m WHERE m.mentee_id = me.id AND m.status = 'active')) AS requested_by_unmatched,
              (SELECT COUNT(*) FROM mentor_expertise x JOIN mentors mo ON mo.id = x.mentor_id
                WHERE x.category_id = c.id AND mo.status = 'active') AS mentors_offering
         FROM expertise_categories c ORDER BY requested DESC, c.name`
    )
    .all()
    .map((row) => ({ ...row, demand_supply_gap: row.requested - row.mentors_offering }));

  const feedback = db
    .prepare('SELECT from_role, ROUND(AVG(rating),2) AS avg_rating, COUNT(*) AS count FROM feedback GROUP BY from_role')
    .all();
  const unmatched = db
    .prepare(
      `SELECT me.id AS mentee_id, u.name, me.programme
         FROM mentees me JOIN users u ON u.id = me.user_id
        WHERE me.status = 'active'
          AND NOT EXISTS (SELECT 1 FROM matches m WHERE m.mentee_id = me.id AND m.status = 'active')
        ORDER BY u.name`
    )
    .all();

  const cutoff = new Date(new Date(now).getTime() - 30 * 86400000).toISOString();
  const stalled = db
    .prepare(
      `SELECT m.id AS match_id, mu.name AS mentor_name, eu.name AS mentee_name,
              MAX(CASE WHEN s.status = 'completed' THEN s.start_at END) AS last_completed_session
         FROM matches m JOIN mentors mo ON mo.id = m.mentor_id JOIN users mu ON mu.id = mo.user_id
         JOIN mentees me ON me.id = m.mentee_id JOIN users eu ON eu.id = me.user_id
         LEFT JOIN sessions s ON s.match_id = m.id
        WHERE m.status = 'active'
        GROUP BY m.id
       HAVING (last_completed_session IS NULL OR last_completed_session < ?)
          AND SUM(CASE WHEN s.status IN ('requested','confirmed') AND s.start_at >= ? THEN 1 ELSE 0 END) = 0`
    )
    .all(cutoff, now);

  const totalSessions = Object.values(sessionsByStatus).reduce((sum, count) => sum + count, 0);
  const totalMentees = Object.values(menteeStatus).reduce((sum, count) => sum + count, 0);
  const activeMentees = menteeStatus.active;
  const unmatchedActiveMentees = unmatched.length;

  return {
    filters: { from: from || null, to: to || null },
    totals: {
      mentors: { total: mentorStatus.active + mentorStatus.paused + mentorStatus.inactive, ...mentorStatus },
      mentees: {
        total: totalMentees,
        active: activeMentees,
        matched: matchedActiveMentees,
        unmatched: unmatchedActiveMentees,
      },
      active_matches: activeMatches,
      mentors_at_capacity: mentors.filter((mentor) => mentor.full && mentor.status === 'active').length,
    },
    sessions: {
      counts: sessionsByStatus,
      total: totalSessions,
      no_show_rate_pct: pct(sessionsByStatus.no_show, sessionsByStatus.completed + sessionsByStatus.no_show),
    },
    hours: { total_hours: hrs(totalMinutes), by_month: hoursByMonth },
    mentors,
    requested_expertise: requestedExpertise,
    actions: tally(
      db.prepare(`SELECT ${DISPLAY_STATUS} AS k, COUNT(*) AS c FROM actions a GROUP BY k`).all(),
      ACTION_STATUSES
    ),
    feedback_averages: feedback,
    attention: { unmatched_mentees: unmatched, stalled_matches: stalled },
  };
}

function adminSummary(report) {
  return {
    mentors: report.totals.mentors.total,
    mentees: report.totals.mentees.total,
    sessions: report.sessions.total,
    completed_sessions: report.sessions.counts.completed,
    total_hours: report.hours.total_hours,
    no_shows: report.sessions.counts.no_show,
  };
}

module.exports = { buildAdminReport, adminSummary, validateDateRange };
