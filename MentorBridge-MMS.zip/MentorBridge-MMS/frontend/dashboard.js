Object.assign(API, {
  adminDashboard: (from, to) => request("GET", "/api/reports/dashboard", undefined, { from, to }),
  reportSummary: (from, to) => request("GET", "/api/reports/summary", undefined, { from, to }),
  reportCapacity: (from, to) => request("GET", "/api/reports/capacity", undefined, { from, to }),
  reportExpertise: (from, to) => request("GET", "/api/reports/expertise", undefined, { from, to }),
});

async function renderAdminOverview() {
  const box = $("admin-overview-content");
  const from = ($("filter-from") || {}).value;
  const to = ($("filter-to") || {}).value;
  if (!$("filter-from")) loading(box);
  try {
    const d = await API.adminDashboard(from, to);
    const c = d.sessions.counts;
    const maxH = Math.max(1, ...d.hours.by_month.map((m) => m.hours));
    box.innerHTML = `
      <div class="filter-row">
        <label>From <input type="date" id="filter-from" value="${esc(from || "")}" /></label>
        <label>To <input type="date" id="filter-to" value="${esc(to || "")}" /></label>
        <button class="btn-small btn-primary" onclick="renderAdminOverview()">Apply</button>
        <button class="btn-small btn-secondary" onclick="clearAdminFilter()">Clear</button>
      </div>
      <div class="stats-overview">
        ${statCard(d.hours.total_hours + " hrs", "Total mentoring hours")}
        ${statCard(d.totals.active_matches, "Active matches")}
        ${statCard(c.completed, "Sessions completed")}
        ${statCard(c.no_show + (d.sessions.no_show_rate_pct === null ? "" : ` (${d.sessions.no_show_rate_pct}%)`), "No-shows", c.no_show ? "stat-warn" : "")}
        ${statCard(d.totals.mentors.active + " / " + d.totals.mentors.total, "Active mentors")}
        ${statCard(d.totals.mentees.total, "Total mentees")}
        ${statCard(d.totals.mentees.matched + " / " + d.totals.mentees.active, "Active mentees matched")}
        ${statCard(d.totals.mentors_at_capacity, "Mentors at capacity")}
        ${statCard(d.sessions.total, "Total sessions")}
      </div>
      <div class="dash-grid">
        <div class="panel-block"><h3>Sessions by status</h3>${Object.entries(c).map(([k, v]) => `<p>${badge(k)} <strong>${v}</strong></p>`).join("")}</div>
        <div class="panel-block"><h3>Actions by status</h3>${Object.entries(d.actions).map(([k, v]) => `<p>${badge(k)} <strong>${v}</strong></p>`).join("")}</div>
        <div class="panel-block"><h3>Hours by month</h3>${
          d.hours.by_month.length ? d.hours.by_month.map((m) => `<div class="bar-row"><span>${esc(m.month)}</span><div class="factor-bar"><div style="width:${Math.round((m.hours / maxH) * 100)}%"></div></div><span>${m.hours} h</span></div>`).join("") : `<p class="muted">No completed sessions in this period.</p>`
        }</div>
        <div class="panel-block"><h3>Feedback averages</h3>${
          d.feedback_averages.length ? d.feedback_averages.map((f) => `<p>${esc(label(f.from_role))}: <strong>${f.avg_rating}</strong> / 5 <span class="muted">(${f.count} responses)</span></p>`).join("") : `<p class="muted">No feedback yet.</p>`
        }</div>
        <div class="panel-block panel-wide"><h3>Requested expertise vs supply</h3>
          <table class="data-table"><thead><tr><th>Expertise</th><th>Active requests</th><th>By unmatched</th><th>Active mentors offering</th><th>Demand gap</th></tr></thead><tbody>
          ${d.requested_expertise.map((e) => `<tr><td>${esc(e.category)}</td><td>${e.requested}</td><td>${e.requested_by_unmatched}</td><td>${e.mentors_offering}</td><td class="${e.demand_supply_gap > 0 ? "text-danger" : ""}">${e.demand_supply_gap > 0 ? `${e.demand_supply_gap} over supply` : "Covered"}</td></tr>`).join("")}
          </tbody></table></div>
        <div class="panel-block"><h3>Mentees without a mentor (${d.attention.unmatched_mentees.length})</h3>${
          d.attention.unmatched_mentees.length ? d.attention.unmatched_mentees.map((m) => `<p>${esc(m.name)} <span class="muted">· ${esc(m.programme)}</span></p>`).join("") : `<p class="muted">Everyone is matched.</p>`
        }</div>
        <div class="panel-block"><h3>Stalled relationships (${d.attention.stalled_matches.length})</h3>${
          d.attention.stalled_matches.length ? d.attention.stalled_matches.map((m) => `<p>${esc(m.mentee_name)} ↔ ${esc(m.mentor_name)} <span class="muted">· last session ${fmtDate(m.last_completed_session)}</span></p>`).join("") : `<p class="muted">No relationships stalling (no session in 30 days and none booked).</p>`
        }</div>
      </div>`;
  } catch (err) { showError(box, err); }
}

function clearAdminFilter() {
  $("filter-from").value = "";
  $("filter-to").value = "";
  renderAdminOverview();
}

async function renderAdminMentors() {
  const box = $("admin-mentors-content");
  loading(box);
  try {
    const d = await API.adminDashboard();
    box.innerHTML = `<table class="data-table"><thead><tr><th>Mentor</th><th>Status</th><th>Rate</th><th>Capacity</th><th>Hours</th><th>Completed</th><th>No-shows</th></tr></thead><tbody>
      ${d.mentors.map((m) => {
        const pct = m.capacity ? Math.min(100, Math.round((m.active_mentees / m.capacity) * 100)) : 100;
        const capacityLabel = m.active_mentees > m.capacity
          ? `${m.active_mentees}/${m.capacity} · over capacity`
          : m.full
            ? `${m.active_mentees}/${m.capacity} · full`
            : `${m.active_mentees}/${m.capacity} · ${m.remaining} available`;
        return `<tr><td>${esc(m.name)}</td><td>${badge(m.status)}</td><td>${formatRate(m.hourly_rate)}</td>
          <td><div class="bar-row"><div class="progress-bar-bg"><div class="progress-bar-fill ${m.full ? "fill-full" : ""}" style="width:${pct}%"></div></div><span>${capacityLabel}</span></div></td>
          <td>${m.hours}</td><td>${m.completed_sessions}</td><td class="${m.no_shows ? "text-danger" : ""}">${m.no_shows}</td></tr>`;
      }).join("")}</tbody></table>`;
  } catch (err) { showError(box, err); }
}
