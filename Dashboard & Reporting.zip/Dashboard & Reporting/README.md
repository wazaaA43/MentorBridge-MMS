# Dashboard & Reporting

This folder isolates the dashboard reporting feature while continuing to use the main MentorBridge frontend and SQLite-backed Express application.

## Feature files

- `backend/services/reporting.js` — SQL-backed admin reporting calculations.
- `backend/routes/reports.js` — authenticated reporting API endpoints.
- `backend/test/reporting.test.js` — report calculation tests.
- `frontend/dashboard.js` — admin reporting API client methods and dashboard rendering.

The app loads `frontend/dashboard.js` from `frontend/index.html`. The Express server mounts the reporting routes from `backend/src/app.js`; the feature reuses the existing database, schema and authentication middleware under `backend/src`.

Endpoints: `/api/reports/summary`, `/api/reports/capacity`, `/api/reports/expertise`, and `/api/reports/dashboard`. The report endpoints require an admin or coach bearer token.

Run the reporting tests from the `backend` directory with:

```powershell
node --test test/scoring.test.js "..\Dashboard & Reporting\backend\test\reporting.test.js"
```
