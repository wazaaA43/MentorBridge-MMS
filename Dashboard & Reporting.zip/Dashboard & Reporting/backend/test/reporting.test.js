const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');
const Database = require('better-sqlite3');
const { buildAdminReport, adminSummary } = require('../services/reporting');

function createDatabase() {
  const db = new Database(':memory:');
  db.pragma('foreign_keys = ON');
  db.exec(fs.readFileSync(path.join(__dirname, '..', '..', '..', 'backend', 'src', 'schema.sql'), 'utf8'));

  const insertUser = db.prepare('INSERT INTO users (name, email, password_hash, role) VALUES (?, ?, ?, ?)');
  insertUser.run('Active Mentor', 'mentor@example.com', 'hash', 'mentor');
  insertUser.run('Paused Mentor', 'paused@example.com', 'hash', 'mentor');
  insertUser.run('Matched Mentee', 'matched@example.com', 'hash', 'mentee');
  insertUser.run('Unmatched Mentee', 'unmatched@example.com', 'hash', 'mentee');
  insertUser.run('Former Mentee', 'former@example.com', 'hash', 'mentee');

  db.prepare("INSERT INTO mentors (user_id, capacity, status) VALUES (1, 1, 'active'), (2, 3, 'paused')").run();
  db.prepare("INSERT INTO mentees (user_id, programme, status) VALUES (3, 'Launch', 'active'), (4, 'Launch', 'active'), (5, 'Launch', 'completed')").run();
  db.prepare("INSERT INTO expertise_categories (name) VALUES ('Finance')").run();
  db.prepare('INSERT INTO mentor_expertise (mentor_id, category_id) VALUES (1, 1), (2, 1)').run();
  db.prepare('INSERT INTO mentee_needs (mentee_id, category_id) VALUES (1, 1), (2, 1), (3, 1)').run();
  db.prepare("INSERT INTO matches (mentee_id, mentor_id, status) VALUES (1, 1, 'active')").run();
  db.prepare(
    `INSERT INTO sessions (match_id, start_at, end_at, status, duration_min) VALUES
     (1, '2026-10-05T10:00:00.000Z', '2026-10-05T11:30:00.000Z', 'completed', 90),
     (1, '2026-10-04T10:00:00.000Z', '2026-10-04T11:00:00.000Z', 'no_show', 0),
     (1, '2026-10-07T10:00:00.000Z', '2026-10-07T11:00:00.000Z', 'confirmed', NULL)`
  ).run();
  return db;
}

test('admin reporting derives counts, mentoring hours, capacity and expertise from SQLite', (t) => {
  const db = createDatabase();
  t.after(() => db.close());

  const report = buildAdminReport(db, { now: '2026-10-06T12:00:00.000Z' });

  assert.deepStrictEqual(adminSummary(report), {
    mentors: 2,
    mentees: 3,
    sessions: 3,
    completed_sessions: 1,
    total_hours: 1.5,
    no_shows: 1,
  });
  assert.deepStrictEqual(report.totals.mentees, {
    total: 3,
    active: 2,
    matched: 1,
    unmatched: 1,
  });
  assert.deepStrictEqual(report.attention.unmatched_mentees.map((mentee) => mentee.name), ['Unmatched Mentee']);
  assert.deepStrictEqual(
    (({ active_mentees, remaining, full, hours, completed_sessions, no_shows }) => ({
      active_mentees, remaining, full, hours, completed_sessions, no_shows,
    }))(report.mentors[0]),
    { active_mentees: 1, remaining: 0, full: true, hours: 1.5, completed_sessions: 1, no_shows: 1 }
  );
  assert.deepStrictEqual(report.requested_expertise[0], {
    category: 'Finance',
    requested: 2,
    requested_by_unmatched: 1,
    mentors_offering: 1,
    demand_supply_gap: 1,
  });
});

test('admin reporting applies date filters to session-based metrics', (t) => {
  const db = createDatabase();
  t.after(() => db.close());

  const report = buildAdminReport(db, {
    from: '2026-10-06',
    to: '2026-10-31',
    now: '2026-10-06T12:00:00.000Z',
  });

  assert.strictEqual(report.sessions.total, 1);
  assert.strictEqual(report.sessions.counts.confirmed, 1);
  assert.strictEqual(report.hours.total_hours, 0);
  assert.strictEqual(report.mentors[0].completed_sessions, 0);
  assert.deepStrictEqual(report.filters, { from: '2026-10-06', to: '2026-10-31' });
});

test('admin reporting rejects malformed date filters', (t) => {
  const db = createDatabase();
  t.after(() => db.close());

  assert.throws(() => buildAdminReport(db, { from: 'October 6, 2026' }), {
    status: 400,
    message: 'from and to must be YYYY-MM-DD',
  });
});
